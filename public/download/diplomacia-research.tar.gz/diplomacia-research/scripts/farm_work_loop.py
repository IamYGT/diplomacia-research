#!/usr/bin/env python3
"""
Tek hesap bakiye farm döngüsü (tutorial bittikten sonra).
1) Can iksiri (cooldown ~10 dk)
2) Kendi fabrikana katıl
3) Çalış → ~2400 altın + 20 elmas
"""
import json
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

AUTH = Path("/root/diplomacia-auth.json")
BASE = "https://diplomacia.com.tr/api"
DELAY = 3.5


def load():
    a = json.loads(AUTH.read_text())
    return a["token"]


def api(method, path, token, body=None):
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Origin": "https://diplomacia.com.tr",
        "Referer": "https://diplomacia.com.tr/",
    }
    data = None
    if body is not None:
        headers["Content-Type"] = "application/json"
        data = json.dumps(body).encode()
    time.sleep(DELAY)
    req = urllib.request.Request(BASE + path, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read().decode())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode())


def balance(token):
    _, d = api("GET", "/players/profile", token)
    p = d.get("player", {})
    return p.get("balance"), p.get("health"), p.get("health_pills")


def main():
    token = load()
    cycles = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    b0, _, _ = balance(token)
    print(f"Başlangıç bakiye: {b0:,}")

    _, prof0 = api("GET", "/players/profile", token)
    current_province = (prof0.get("player") or {}).get("province_name")

    def pick_factory_id() -> str:
        _, fac = api("GET", "/factories/my", token)
        factories = fac.get("factories", [])
        if not factories:
            st, built = api("POST", "/factories/build", token, {"type": "elmas", "name": "FarmLoop"})
            if st not in (200, 201):
                print("Fabrika kurulamadı:", built)
                sys.exit(1)
            return (built.get("factory") or {}).get("id") or factories[0]["id"]
        if current_province:
            local = [f for f in factories if f.get("province_name") == current_province]
            if local:
                return local[0]["id"]
        return factories[0]["id"]

    fid = pick_factory_id()

    for i in range(cycles):
        print(f"\n--- Döngü {i + 1}/{cycles} ---")
        _, ws = api("GET", "/factories/work-status", token)
        if ws.get("working"):
            st, left = api("POST", "/factories/leave", token, {})
            print("leave:", left.get("message") or left.get("error"))
        fid = pick_factory_id()
        st, j = api("POST", "/factories/join", token, {"factory_id": fid})
        print("join:", j.get("message") or j.get("error"))
        if j.get("error") and "bölge" in str(j.get("error")).lower():
            st, built = api("POST", "/factories/build", token, {"type": "elmas", "name": f"FarmLoop{i}"})
            if st in (200, 201):
                fid = (built.get("factory") or {}).get("id", fid)
                st, j = api("POST", "/factories/join", token, {"factory_id": fid})
                print("join(retry):", j.get("message") or j.get("error"))

        _, h = api("GET", "/players/profile", token)
        health = h.get("player", {}).get("health", 0)
        if health < 100:
            st, pills = api("POST", "/auto/use-pills", token, {})
            print("use-pills:", pills)
            if pills.get("error"):
                print("Can bekleniyor — 10 dk pill cooldown veya health regen")
                break

        st, work = api("POST", "/factories/work", token, {})
        earned = (work.get("earned") or {}).get("money", 0)
        print("work:", work.get("message") or work.get("error"), f"+{earned} altın" if earned else "")

    b1, _, _ = balance(token)
    print(f"\nSon bakiye: {b1:,}  (delta: {b1 - b0:+,})")


if __name__ == "__main__":
    main()
